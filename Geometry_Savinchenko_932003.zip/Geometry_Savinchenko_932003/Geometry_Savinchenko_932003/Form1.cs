﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Geometry_Savinchenko_932003
{
    public partial class Form1 : Form
    {
        public static Bitmap image;
        public static double x1 = 50, y1 = 100, x2 = 325, y2 = 300, x3 = 600, y3 = 100;
        private readonly Color redColor = Color.Red;
        private readonly Color greenColor = Color.Green;
        private readonly Color blueColor = Color.Blue;
        Color pixelPosition;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            image = new Bitmap(pictureBox.Width, pictureBox.Height);
            paint();
            pictureBox.Image = image;
        }

        public void paint()
        {
            for (int y = 0; y < pictureBox.Height; y++)
            {
                for (int x = 0; x < pictureBox.Width; x++)
                {
                    image.SetPixel(x, y, affine_transformation(x, y));
                }  
            }     
        }

        public Color affine_transformation(int x, int y)
        {
            pixelPosition = Color.White; ;
            double l1, l2, l3;

            l1 = ((y2 - y3) * ((double)(x) - x3) + (x3 - x2) * ((double)(y) - y3)) / ((y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3));
            l2 = ((y3 - y1) * ((double)(x) - x3) + (x1 - x3) * ((double)(y) - y3)) / ((y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3));
            l3 = 1 - l1 - l2;

            if (l1 >= 0 && l1 <= 1 && l2 >= 0 && l2 <= 1 && l3 >= 0 && l3 <= 1)
            {
                var red = (int)(l1 * redColor.R + l2 * greenColor.R + l3 * blueColor.R);
                var green = (int)(l1 * redColor.G + l2 * greenColor.G + l3 * blueColor.G);
                var blue = (int)(l1 * redColor.B + l2 * greenColor.B + l3 * blueColor.B);
                pixelPosition = Color.FromArgb(red, green, blue);
            }
            return pixelPosition;
        }
    }
}
